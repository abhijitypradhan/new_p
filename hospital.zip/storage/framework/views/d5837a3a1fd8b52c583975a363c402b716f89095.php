<!DOCTYPE html>
<html lang="en">
  <head>
  <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
    
      <!-- partial:partials/_sidebar.html -->
     <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_navbar.html -->
       <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->

        <div class="container-fluid page-body-wrapper">

        <div class="container"  align="center" style="margin-top:120px;">

<table style="background-color:black;color:white;">
     <tr style="padding:10px">
           <th style="padding:10px">Doctor name</th>
           <th style="padding:10px">Phone no</th>
           <th style="padding:10px">Speciality</th>
           <th style="padding:10px">Room</th>
           <th style="padding:10px">image</th>
           <th style="padding:10px">Update</th>
           <th style="padding:10px">Delete</th>
          
      </tr>
     <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr align="center" style="background-color:blue;color:white;">
       <td><?php echo e($datas->name); ?></td>
       <td><?php echo e($datas->phone); ?> </td>
       <td><?php echo e($datas->speciality); ?> </td>
       <td><?php echo e($datas->room); ?> </td>
       <td><img src="doctorimage/<?php echo e($datas->image); ?>" height="70px" width="70px"></td>
       
      <td> <a class="btn btn-primary" href="<?php echo e(url('updatedoctor',$datas->id)); ?>">Update</a></td>
      <td><a onclick="return confirm('Are you sure to delete this')" class="btn btn-danger" href="<?php echo e(url('deletedoctor',$datas->id)); ?>" >Delete</a></td>
      </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>

</div>
        </div>
     
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End custom js for this page -->
  </body>
</html><?php /**PATH F:\laravel_project\Hospital\resources\views/admin/showdoctor.blade.php ENDPATH**/ ?>