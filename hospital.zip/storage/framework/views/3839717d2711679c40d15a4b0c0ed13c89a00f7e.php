<!DOCTYPE html>
<html lang="en">
  <head>
  <base href="/public">
  <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  </head>
  <body>
    <div class="container-scroller">
    
      <!-- partial:partials/_sidebar.html -->
     <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
     
       
       <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <div class="container-fluid page-body-wrapper">


      
         
       <div class="container" style="margin-top: 100px;">

       <?php if(session()->has('message')): ?>

<div class="alert alert-success">
  <button type="button" class="close" data-dismiss="alert">x</button>

  <?php echo e(session()->get('message')); ?>


</div>
 <?php endif; ?>
       <div class="form-group" >
         <form action="<?php echo e(url('sendemail',$data->id)); ?>" method="POST" >

         <?php echo csrf_field(); ?>
          <div>
           <label>Greeting *</label>
          <input type="text" name="greeting" placeholder="Write your greeting" style="color:blue;"  class="form-control" required="">
        </div>

        <div>
           <label>Body*</label>
          <input type="text" name="body" placeholder="Write the body content" style="color:blue;" class="form-control" required="">
        </div>

      

        <div>
           <label>Action Text *</label>
          <input type="text" style="color:blue;" name="actiontext" placeholder="Write action text content" class="form-control" required="">
        </div>

        <div>
           <label>Action Url *</label>
          <input type="text" style="color:blue;" name="actionurl" placeholder="Write actionurl" class="form-control" required="">
        </div>

        <div>
           <label>End Part *</label>
          <input type="text" style="color:blue;" name="endpart" placeholder="Write end Part" class="form-control" required="">
        </div>
<br></br>
           <input type="submit" name="submit" class="btn btn-success" value="submit">
        </form>
        </div>
           </div>

       </div>

      <!-- page-body-wrapper ends -->
    
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End custom js for this page -->
  </body>
</html><?php /**PATH F:\laravel_project\hospital\resources\views/admin/email_view.blade.php ENDPATH**/ ?>