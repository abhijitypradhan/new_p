<!DOCTYPE html>
<html lang="en">
  <head>
    <base href="/public">
  <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
    
      <!-- partial:partials/_sidebar.html -->
     <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_navbar.html -->
       <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
       
        <div class="container-fluid page-body-wrapper">



        <div class="container" style="margin-top: 100px;">

        
        <?php if(session()->has('message')): ?>

<div class="alert alert-success">
  <button type="button" class="close" data-dismiss="alert">x</button>

  <?php echo e(session()->get('message')); ?>


</div>
 <?php endif; ?>
        
        <div class="form-group" >
         <form action="<?php echo e(url('editdoctor',$data->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
         <div>
          <label>Doctor Name *</label>
          <input type="text" name="doctor_name" value="<?php echo e($data->name); ?>" style="color:blue;"  class="form-control" required="">
        </div>
          

        <div>
           <label>Phone No *</label>
          <input type="number" name="number" value="<?php echo e($data->phone); ?>" style="color:blue;" class="form-control" required="">
        </div>

        <div>
           <label>Speciality *</label>
           <input type="text" name="speciality" value="<?php echo e($data->speciality); ?>" style="color:blue;" class="form-control" required="">
        </div>

        <div>
           <label>Room No *</label>
          <input type="text" style="color:blue;" name="room" value="<?php echo e($data->room); ?>" class="form-control" required="">
        </div>

        <div>
           <label>Old Image *</label>
         <img height="100px" width="100px" src="doctorimage/<?php echo e($data->image); ?>">
        </div>

<br>
        <div>
           <label>New Image *</label>
          <input type="file"  name="file"  class="form-control" >
        </div>

           <input type="submit" name="submit" class="btn btn-success" value="submit">
        </form>
        </div>

        </div>
        </div>

        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End custom js for this page -->
  </body>
</html><?php /**PATH F:\laravel_project\Hospital\resources\views/admin/update_doctor.blade.php ENDPATH**/ ?>