<?php echo e($slot); ?>

<?php /**PATH F:\laravel_project\Hospital\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>