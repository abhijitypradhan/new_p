<?php echo e($slot); ?>

<?php /**PATH F:\laravel_project\hospital\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>